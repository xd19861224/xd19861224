#!/bin/sh

mysql_config="/root/crm9/config/config/crm9-config.txt"
mysql_config_bak="/root/crm9/config/config/crm9-config.txt.bak"
redis_config="/root/crm9/config/config/redis.json"
redis_config_bak="/root/crm9/config/config/redis.json.bak"
# 如果备份文件不存在
if [ ! -f "${mysql_config_bak}" ]; then
  cp ${mysql_config} ${mysql_config_bak}
fi

if [ ! -f "${redis_config_bak}" ]; then
  cp ${redis_config} ${redis_config_bak}
fi

# mysql
sed "s/127.0.0.1:3306/${mysql_ip_port}/g;\
     s/root/${mysql_username}/g;\
     s/123456/${mysql_password}/g" ${mysql_config_bak} > ${mysql_config}
# redis
sed "s/127.0.0.1:6379/${redis_ip_port}/g;\
     s/123456/${redis_pasword}/g;\
     s/:0/:${redis_database}/g" ${redis_config_bak} > ${redis_config}

# crm9
JAVA_OPTS="-Xverify:none -Dundertow.port=80"
CP="/root/crm9/config:/root/crm9/lib/*"
MAIN_CLASS="com.kakarote.crm9.Application"

java -Xverify:none ${JAVA_OPTS} -cp ${CP} ${MAIN_CLASS}